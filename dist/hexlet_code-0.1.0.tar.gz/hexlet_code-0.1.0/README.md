### Hexlet tests and linter status:
[![Actions Status](https://github.com/Aatem/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Aatem/python-project-49/actions)

<a href="https://codeclimate.com/github/Aatem/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2a8fe0d5dc49bd4b390e/maintainability" /></a>

Brain games

Первая игра: Brain-even
Проверка на чётность.
<a href="https://asciinema.org/a/hn8qhdOVZ7rd1qHBh07JaGCoY" target="_blank"><img src="https://asciinema.org/a/hn8qhdOVZ7rd1qHBh07JaGCoY.svg" /></a>

Вторая игра: Brain-calc
Решение математических выражений.
<a href="https://asciinema.org/a/sd6A6HyiROwuYSZY9WrQrmXJY" target="_blank"><img src="https://asciinema.org/a/sd6A6HyiROwuYSZY9WrQrmXJY.svg" /></a>

Третья игра: Brain-gcd
Нахождение наибольшего общего делителя двух чисел.
<a href="https://asciinema.org/a/uvIkTProbj1IZD7KoO4agtz3u" target="_blank"><img src="https://asciinema.org/a/uvIkTProbj1IZD7KoO4agtz3u.svg" /></a>

Четвёртая игра: Brain-progression
Нахождение пропущенного числа в математической прогрессии.
<a href="https://asciinema.org/a/Bb11KBLYmVU0HyZgt6nndr0rr" target="_blank"><img src="https://asciinema.org/a/Bb11KBLYmVU0HyZgt6nndr0rr.svg" /></a>

Пятая игра: Brain-prime
Проверка числа на простоту.
<a href="https://asciinema.org/a/tUMYLj5hSyaEvefJmz16bD6Wo" target="_blank"><img src="https://asciinema.org/a/tUMYLj5hSyaEvefJmz16bD6Wo.svg" /></a>