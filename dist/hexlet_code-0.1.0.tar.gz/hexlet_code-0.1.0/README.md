### Hexlet tests and linter status:
[![Actions Status](https://github.com/Aatem/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Aatem/python-project-49/actions)

<a href="https://codeclimate.com/github/Aatem/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2a8fe0d5dc49bd4b390e/maintainability" /></a>

https://asciinema.org/a/hn8qhdOVZ7rd1qHBh07JaGCoY

https://asciinema.org/a/sd6A6HyiROwuYSZY9WrQrmXJY

https://asciinema.org/a/uvIkTProbj1IZD7KoO4agtz3u

https://asciinema.org/a/Bb11KBLYmVU0HyZgt6nndr0rr